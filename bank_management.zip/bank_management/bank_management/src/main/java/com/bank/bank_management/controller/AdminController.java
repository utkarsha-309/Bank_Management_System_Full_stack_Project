package com.bank.bank_management.controller;
import com.bank.bank_management.model.*;
import com.bank.bank_management.service.*;
import com.bank.bank_management.repository.*;
import com.bank.bank_management.security.JwtUtil;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private BankAccountService bankAccountService;
	
	@Autowired
	private PasswordEncoder passwordEncoder; // ✅ Add this to the top of the class

	@PostMapping("/registeradmin")
    public Admin registerAdmin(@RequestBody Map<String, String> request) {
        return adminService.registerAdmin(request.get("username"), request.get("password"));
    }
	
	@PostMapping("/login")
	public ResponseEntity<Map<String, String>> login(@RequestBody Map<String, String> request) {
	    String username = request.get("username");
	    String password = request.get("password");

	    Optional<Admin> admin = adminService.findByUsername(username);
	    if (admin.isEmpty() || !passwordEncoder.matches(password, admin.get().getPassword())) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid credentials"));
	    }

	    String token = jwtUtil.generateToken(username);
	    return ResponseEntity.ok(Map.of("token", token));
	}

	
	@GetMapping("/accounts")
	@PreAuthorize("hasRole('ADMIN')")
	public List<BankAccount> getAllAccounts(){
		return bankAccountService.getAllAccounts();
	}
	@GetMapping("/transactions/{accountnumber}")
	@PreAuthorize("hasRole('ADMIN')")
	public List<Transaction> getAllTransactions(@PathVariable String accountnumber){
		return bankAccountService.getTransactionHistory(accountnumber);
	}
	
	@DeleteMapping("/delete-account/{accountNumber}")
	public String deleteAccount(@PathVariable String accountNumber) {
		bankAccountService.deleteAccount(accountNumber);
		return "Account deleted successfully!!";
	}

}
