package com.bank.bank_management.model;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name ="transactions")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String accountNumber;
	
	@Column(nullable = false)
	private String type; //deposie,Withdrawal,transfer
	
	@Column(nullable = false)
	private BigDecimal amount;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date transactionDate;

	public Transaction() {
		super();
	}

	public Transaction(String accountNumber, String type, BigDecimal amount, Date transactionDate) {
		super();
		this.accountNumber = accountNumber;
		this.type = type;
		this.amount = amount;
		this.transactionDate = transactionDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	
	
	//private String description;
	
//	@ManyToOne  //(many transaction occour by 1 account)
//	@JoinColumn(name = "account_id" ,nullable = false)
//	private Account account;
//	
//	@Column(nullable = false)
//	private LocalDateTime timestamp = LocalDateTime.now();
}
