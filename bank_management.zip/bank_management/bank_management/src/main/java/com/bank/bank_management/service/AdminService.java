package com.bank.bank_management.service;
import com.bank.bank_management.model.*;
import com.bank.bank_management.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class AdminService {
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public Admin registerAdmin(String username,String password) {
		if(adminRepository.findByUsername(username).isPresent()) {
			throw new RuntimeException("Username already registered!!");
		}
		String hashedPassword = passwordEncoder.encode(password);
		Admin admin = new Admin(username,hashedPassword);
		return adminRepository.save(admin);
	}
	
	public Optional<Admin> findByUsername(String username){
		return adminRepository.findByUsername(username);
	}
}
