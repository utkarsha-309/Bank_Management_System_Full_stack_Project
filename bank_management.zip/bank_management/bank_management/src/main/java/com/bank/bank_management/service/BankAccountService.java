package com.bank.bank_management.service;
import com.bank.bank_management.model.*;
import com.bank.bank_management.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BankAccountService {
	@Autowired
	private BankAccountRepository bankAccountRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	//to create new account
	public BankAccount createAccount(String accountNumber,String accountHolder,BigDecimal initialDeposite) {
		if(bankAccountRepository.findByAccountNumber(accountNumber).isPresent()) {
			throw new RuntimeException("Account Number already exists!");
		}
		
		BankAccount newAccount = new BankAccount(accountNumber,accountHolder,initialDeposite);
		return bankAccountRepository.save(newAccount);
	}
	
	//to get account details
	
	public Optional<BankAccount> getAccountDetails(String accountNumber){
		return bankAccountRepository.findByAccountNumber(accountNumber);
	}
	
	//deposit the amount
	
	@Transactional
	public void deposite(String accountNumber , BigDecimal amount) {
		BankAccount account = bankAccountRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new RuntimeException("Account not found!!"));
		account.setBalance(account.getBalance().add(amount));
		bankAccountRepository.save(account);
	
		transactionRepository.save(new Transaction(accountNumber,"DEPOSITE" , amount , new Date()));
	}
	
	//Withdraw the amount 
	@Transactional
	public void withdraw(String accountNumber, BigDecimal amount) {
		BankAccount account = bankAccountRepository.findByAccountNumber(accountNumber)
					.orElseThrow(()->new RuntimeException("Account not found!!"));
		
		if(account.getBalance().compareTo(amount)<0) {
			throw new RuntimeException("Insufficient Balance!!");
		}
		
		account.setBalance(account.getBalance().subtract(amount));
		bankAccountRepository.save(account);
		
		transactionRepository.save(new Transaction(accountNumber,"DEPOSITE" , amount , new Date()));
	}
	
	//Transfer the amount
	@Transactional
	public void transfer(String fromAccount, String toAccount,BigDecimal amount) {
		withdraw(fromAccount, amount);
		deposite(toAccount, amount);
		transactionRepository.save(new Transaction(fromAccount,"Transfer",amount,new Date()));
		
	}
	
	public List<Transaction> getTransactionHistory(String accountNumber){
		return transactionRepository.findByAccountNumber(accountNumber);
		
	}
	
	
	public List<BankAccount> getAllAccounts(){
		return bankAccountRepository.findAll();
	}
	
	//delete the account
	public void deleteAccount(String accountNumber) {
		BankAccount account = bankAccountRepository.findByAccountNumber(accountNumber)
							.orElseThrow(()->new RuntimeException("Account not found!"));
		bankAccountRepository.delete(account);
	}
}
