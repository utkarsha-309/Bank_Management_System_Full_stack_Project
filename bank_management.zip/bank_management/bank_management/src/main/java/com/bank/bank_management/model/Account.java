package com.bank.bank_management.model;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "accounts")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false,unique = true)
	private String accountNumber;
	
	@Column(nullable = false)
	private BigDecimal balance;
	
	@ManyToOne
	@JoinColumn(name="user_id",nullable = false)
	private User user;
}
