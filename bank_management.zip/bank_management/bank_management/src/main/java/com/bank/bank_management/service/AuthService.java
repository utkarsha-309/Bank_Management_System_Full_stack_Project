package com.bank.bank_management.service;
import com.bank.bank_management.model.*;
import com.bank.bank_management.repository.*;
import com.bank.bank_management.security.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;
import lombok.*;
@Service
public class AuthService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	public String register (User user) {
		//is this user existing or not
		if (userRepository.findByUsername(user.getUsername()).isPresent()) {
		  throw new RuntimeException("Username already existing!!");  
		}
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user.setRole("User");
		userRepository.save(user);
		return "User registered successfully!!";
	}
	
	public String login(String username,String password) {
		Optional<User> user  = userRepository.findByUsername(username);
		if(user.isPresent() && passwordEncoder.matches(password, user.get().getPassword())) {
		return jwtUtil.generateToken(username);
	}
	throw new RuntimeException("Invalid Username or password!!");
	
}
}
