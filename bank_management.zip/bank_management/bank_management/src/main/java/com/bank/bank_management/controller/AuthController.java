package com.bank.bank_management.controller;
import com.bank.bank_management.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.bank.bank_management.service.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;


@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	private AuthService authService;
	
	@PostMapping("/register")
	public String register(@RequestBody User user) {
		return authService.register(user);
		
	}
	@PostMapping("/login")
	public String login(@RequestBody Map<String, String> loginRequest) {
		return authService.login(loginRequest.get("username"),loginRequest.get("password"));
		
	}
}
