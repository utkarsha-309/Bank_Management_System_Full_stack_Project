package com.bank.bank_management.security;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureAlgorithm;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;
import java.util.function.Function;
@Component
public class JwtUtil {
	//command to generate JWT secret key by using cmd 
	//node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
	
	private final String SECRET_KEY = "8c53a5d59b6983204749570c38686df76cb7940623cbe5805ed4bf49bf4fdaac";
	
	private Key getSigningKey() {
		//hmac=node js authentication algorithm
		return Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
		
	}
	public String generateToken(String username) {
		return Jwts.builder()
				   .setSubject(username)
				   .setIssuedAt(new Date())
				   .setExpiration(new Date(System.currentTimeMillis() +  86400000 ))
				   .signWith(getSigningKey() , io.jsonwebtoken.SignatureAlgorithm.HS256) //HS256 = secure version 
				   .compact();
	}
	
	public String extractUsername(String token) {
//		return Jwts.parser()
//				   .setSigningKey(getSigningKey())
//				   .build()
//				   .parseClaimsJws(token)
//				   .getBody()
//				   .getSubject();
		return extractClaim(token, Claims::getSubject);
	}
	
	public Date extractExpiration(String token) {
		//::=Claims tends to getExpiration
		return extractClaim(token, Claims::getExpiration);
	}
	
	public <T> T extractClaim(String token,Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}
	
	private Claims extractAllClaims(String token) {
		return ((JwtParser) Jwts.parser()
			.setSigningKey(SECRET_KEY))
			.parseClaimsJws(token)
			.getBody();
				
	}
	
	
	public boolean validateToken(String token,String username) {
		try {
//			Jwts.parser().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
			return (username.equals(extractUsername(token)) && !isTokenExpired(token));
		} catch (Exception e) {
			return false;
		}
	}
	
	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}
}
