package com.bank.bank_management.repository;
import com.bank.bank_management.model.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{

		Optional<User> findByUsername(String username);
		
}
