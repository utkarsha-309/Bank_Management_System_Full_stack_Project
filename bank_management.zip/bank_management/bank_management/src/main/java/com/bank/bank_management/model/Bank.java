package com.bank.bank_management.model;

import jakarta.persistence.*;
import lombok.*;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name ="bank")
public class Bank {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false ,unique=true)
	private String bankName;
	
	@Column(nullable = false)
	private String branch;
	
	@Column(nullable = false ,unique=true)
	private String swiftCode;
	
}
