package com.bank.bank_management.controller;
import com.bank.bank_management.model.*;
import com.bank.bank_management.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/bank")

public class BankAccountController {
	
	@Autowired
	private BankAccountService bankAccountService;
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/create-account")
	public BankAccount createAccount(@RequestBody Map<String,String> request) {
		return bankAccountService.createAccount(
				request.get("accountNumber"),
				request.get("accountHolder"),
				new BigDecimal(request.get("initialDeposite"))
				);
	}
	
	@GetMapping("/account/{accountNumber}")
	public Optional <BankAccount> getAccountDetails(@PathVariable String accountNumber){
		return bankAccountService.getAccountDetails(accountNumber);
	}
	
	@PostMapping("/deposit")
	public String deposite(@RequestBody Map<String, String> request) {
		bankAccountService.deposite(request.get("accountNumber"), new BigDecimal(request.get("amount")));
		return "Deposite Successfully!!";
	}
	
	@PostMapping("/withdraw")
	public String withdraw( @RequestBody Map<String, String> request) {
		bankAccountService.withdraw(request.get("accountNumber"), new BigDecimal(request.get("amount")));
		return "Withdraw Successfully!!";
	}
	
	@PostMapping("/transfer")
	public String transfer(@RequestBody Map<String,String> request) {
		bankAccountService.transfer(
				request.get("fromAccount"),
				request.get("toAccount"),
				new BigDecimal(request.get("amount"))
				
				);
		return "Transfer successful!!";
	}
	
	@GetMapping("/transaction/{accountNumber}")
	public List<Transaction> getTransactionHistory(@PathVariable String accountNumber){
		return bankAccountService.getTransactionHistory(accountNumber);
		
	}
}
